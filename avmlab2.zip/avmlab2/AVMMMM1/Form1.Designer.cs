﻿namespace QuadIntegralsRunge
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelFunc = new System.Windows.Forms.Label();
            this.textFunc = new System.Windows.Forms.TextBox();
            this.labelA = new System.Windows.Forms.Label();
            this.textA = new System.Windows.Forms.TextBox();
            this.labelB = new System.Windows.Forms.Label();
            this.textB = new System.Windows.Forms.TextBox();
            this.labelEps = new System.Windows.Forms.Label();
            this.textEps = new System.Windows.Forms.TextBox();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.groupRect = new System.Windows.Forms.GroupBox();
            this.lblRectN = new System.Windows.Forms.Label();
            this.lblRectH = new System.Windows.Forms.Label();
            this.lblRectI = new System.Windows.Forms.Label();
            this.groupTrap = new System.Windows.Forms.GroupBox();
            this.lblTrapN = new System.Windows.Forms.Label();
            this.lblTrapH = new System.Windows.Forms.Label();
            this.lblTrapI = new System.Windows.Forms.Label();
            this.groupRect.SuspendLayout();
            this.groupTrap.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelFunc
            // 
            this.labelFunc.AutoSize = true;
            this.labelFunc.Location = new System.Drawing.Point(12, 15);
            this.labelFunc.Name = "labelFunc";
            this.labelFunc.Size = new System.Drawing.Size(91, 13);
            this.labelFunc.TabIndex = 0;
            this.labelFunc.Text = "Функция f(x) =";
            // 
            // textFunc
            // 
            this.textFunc.Location = new System.Drawing.Point(109, 12);
            this.textFunc.Name = "textFunc";
            this.textFunc.Size = new System.Drawing.Size(360, 20);
            this.textFunc.TabIndex = 1;
            this.textFunc.Text = "sin(x)"; // по умолчанию
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Location = new System.Drawing.Point(12, 45);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(88, 13);
            this.labelA.TabIndex = 2;
            this.labelA.Text = "Левая граница a";
            // 
            // textA
            // 
            this.textA.Location = new System.Drawing.Point(109, 42);
            this.textA.Name = "textA";
            this.textA.Size = new System.Drawing.Size(100, 20);
            this.textA.TabIndex = 3;
            this.textA.Text = "0";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Location = new System.Drawing.Point(226, 45);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(96, 13);
            this.labelB.TabIndex = 4;
            this.labelB.Text = "Правая граница b";
            // 
            // textB
            // 
            this.textB.Location = new System.Drawing.Point(328, 42);
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(100, 20);
            this.textB.TabIndex = 5;
            this.textB.Text = "1";
            // 
            // labelEps
            // 
            this.labelEps.AutoSize = true;
            this.labelEps.Location = new System.Drawing.Point(12, 74);
            this.labelEps.Name = "labelEps";
            this.labelEps.Size = new System.Drawing.Size(74, 13);
            this.labelEps.TabIndex = 6;
            this.labelEps.Text = "Точность ε";
            // 
            // textEps
            // 
            this.textEps.Location = new System.Drawing.Point(109, 71);
            this.textEps.Name = "textEps";
            this.textEps.Size = new System.Drawing.Size(100, 20);
            this.textEps.TabIndex = 7;
            this.textEps.Text = "0.001";
            // 
            // buttonCalc
            // 
            this.buttonCalc.Location = new System.Drawing.Point(328, 69);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(141, 23);
            this.buttonCalc.TabIndex = 8;
            this.buttonCalc.Text = "Вычислить";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // groupRect
            // 
            this.groupRect.Controls.Add(this.lblRectN);
            this.groupRect.Controls.Add(this.lblRectH);
            this.groupRect.Controls.Add(this.lblRectI);
            this.groupRect.Location = new System.Drawing.Point(15, 112);
            this.groupRect.Name = "groupRect";
            this.groupRect.Size = new System.Drawing.Size(454, 90);
            this.groupRect.TabIndex = 9;
            this.groupRect.TabStop = false;
            this.groupRect.Text = "Метод левых прямоугольников";
            // 
            // lblRectN
            // 
            this.lblRectN.AutoSize = true;
            this.lblRectN.Location = new System.Drawing.Point(15, 64);
            this.lblRectN.Name = "lblRectN";
            this.lblRectN.Size = new System.Drawing.Size(88, 13);
            this.lblRectN.TabIndex = 2;
            this.lblRectN.Text = "Разбиений: —";
            // 
            // lblRectH
            // 
            this.lblRectH.AutoSize = true;
            this.lblRectH.Location = new System.Drawing.Point(15, 43);
            this.lblRectH.Name = "lblRectH";
            this.lblRectH.Size = new System.Drawing.Size(44, 13);
            this.lblRectH.TabIndex = 1;
            this.lblRectH.Text = "Шаг h: —";
            // 
            // lblRectI
            // 
            this.lblRectI.AutoSize = true;
            this.lblRectI.Location = new System.Drawing.Point(15, 22);
            this.lblRectI.Name = "lblRectI";
            this.lblRectI.Size = new System.Drawing.Size(93, 13);
            this.lblRectI.TabIndex = 0;
            this.lblRectI.Text = "Интеграл I ≈ —";
            // 
            // groupTrap
            // 
            this.groupTrap.Controls.Add(this.lblTrapN);
            this.groupTrap.Controls.Add(this.lblTrapH);
            this.groupTrap.Controls.Add(this.lblTrapI);
            this.groupTrap.Location = new System.Drawing.Point(15, 208);
            this.groupTrap.Name = "groupTrap";
            this.groupTrap.Size = new System.Drawing.Size(454, 90);
            this.groupTrap.TabIndex = 10;
            this.groupTrap.TabStop = false;
            this.groupTrap.Text = "Метод трапеций";
            // 
            // lblTrapN
            // 
            this.lblTrapN.AutoSize = true;
            this.lblTrapN.Location = new System.Drawing.Point(15, 64);
            this.lblTrapN.Name = "lblTrapN";
            this.lblTrapN.Size = new System.Drawing.Size(88, 13);
            this.lblTrapN.TabIndex = 2;
            this.lblTrapN.Text = "Разбиений: —";
            // 
            // lblTrapH
            // 
            this.lblTrapH.AutoSize = true;
            this.lblTrapH.Location = new System.Drawing.Point(15, 43);
            this.lblTrapH.Name = "lblTrapH";
            this.lblTrapH.Size = new System.Drawing.Size(44, 13);
            this.lblTrapH.TabIndex = 1;
            this.lblTrapH.Text = "Шаг h: —";
            // 
            // lblTrapI
            // 
            this.lblTrapI.AutoSize = true;
            this.lblTrapI.Location = new System.Drawing.Point(15, 22);
            this.lblTrapI.Name = "lblTrapI";
            this.lblTrapI.Size = new System.Drawing.Size(93, 13);
            this.lblTrapI.TabIndex = 0;
            this.lblTrapI.Text = "Интеграл I ≈ —";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(485, 314);
            this.Controls.Add(this.groupTrap);
            this.Controls.Add(this.groupRect);
            this.Controls.Add(this.buttonCalc);
            this.Controls.Add(this.textEps);
            this.Controls.Add(this.labelEps);
            this.Controls.Add(this.textB);
            this.Controls.Add(this.labelB);
            this.Controls.Add(this.textA);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.textFunc);
            this.Controls.Add(this.labelFunc);
            this.Name = "Form1";
            this.Text = "Интегралы: прямоугольники и трапеции (Рунге)";
            this.groupRect.ResumeLayout(false);
            this.groupRect.PerformLayout();
            this.groupTrap.ResumeLayout(false);
            this.groupTrap.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label labelFunc;
        private System.Windows.Forms.TextBox textFunc;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.TextBox textA;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.Label labelEps;
        private System.Windows.Forms.TextBox textEps;
        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.GroupBox groupRect;
        private System.Windows.Forms.Label lblRectN;
        private System.Windows.Forms.Label lblRectH;
        private System.Windows.Forms.Label lblRectI;
        private System.Windows.Forms.GroupBox groupTrap;
        private System.Windows.Forms.Label lblTrapN;
        private System.Windows.Forms.Label lblTrapH;
        private System.Windows.Forms.Label lblTrapI;
    }
}
