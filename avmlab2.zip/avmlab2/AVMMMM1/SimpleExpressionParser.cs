﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace QuadIntegralsRunge
{
    // простой парсер:
    // Поддерживает:
    //  - числа: 3, 2.5
    //  - переменную: x
    //  - + - * / ^ (степень право-ассоциативная)
    //  - скобки (...)
    //  - унарный минус: -x, -(1+x)
    //  - функции: sin, cos, tan, exp, ln  (в аргументах — любое выражение)
    //
    // напрример: sin(x)^2 + ln(1+x) / 3
    public class SimpleExpressionParser
    {
        private string _s;
        private int _pos;

        public Func<double, double> Parse(string text)
        {
            _s = text.Replace(" ", "").ToLowerInvariant();
            _pos = 0;
            var node = ParseExpression();

            if (_pos < _s.Length)
                throw new Exception("Лишние символы в конце: '" + _s.Substring(_pos) + "'");

            // Возвращаем функцию f(x)
            double Eval(double x) => node.Eval(x);
            return Eval;
        }

        // grammar:
        // expr = term { (+|-) term }
        // term = power { (*|/) power }
        // power = unary [ ^ power ]   // правая ассоциативность
        // unary = number | x | func '(' expr ')' | '(' expr ')' | '-' unary

        private Node ParseExpression()
        {
            Node left = ParseTerm();
            while (Match('+') || Match('-'))
            {
                char op = _s[_pos - 1];
                Node right = ParseTerm();
                left = new BinaryNode(op, left, right);
            }
            return left;
        }

        private Node ParseTerm()
        {
            Node left = ParsePower();
            while (Match('*') || Match('/'))
            {
                char op = _s[_pos - 1];
                Node right = ParsePower();
                left = new BinaryNode(op, left, right);
            }
            return left;
        }

        private Node ParsePower()
        {
            Node left = ParseUnary();
            if (Match('^'))
            {
                Node right = ParsePower(); // правая ассоциативность
                left = new PowerNode(left, right);
            }
            return left;
        }

        private Node ParseUnary()
        {
            if (Match('-'))
            {
                Node inner = ParseUnary();
                return new UnaryMinusNode(inner);
            }

            if (Match('('))
            {
                Node inside = ParseExpression();
                if (!Match(')')) throw new Exception("Ожидалась закрывающая скобка ')'");
                return inside;
            }

            // функция?
            string func = TryParseFunctionName();
            if (func != null)
            {
                if (!Match('(')) throw new Exception("Ожидалась '(' после имени функции");
                Node arg = ParseExpression();
                if (!Match(')')) throw new Exception("Ожидалась ')' после аргумента функции");
                return new FuncNode(func, arg);
            }

            // переменная x ?
            if (Peek() == 'x')
            {
                _pos++;
                return new VarNode();
            }

            // число
            string num = TryParseNumber();
            if (num != null)
            {
                double val = double.Parse(num, CultureInfo.InvariantCulture);
                return new NumNode(val);
            }

            throw new Exception("Неожиданное место в выражении около: '" + Remaining() + "'");
        }

        private bool Match(char c)
        {
            if (_pos < _s.Length && _s[_pos] == c)
            {
                _pos++;
                return true;
            }
            return false;
        }

        private char Peek()
        {
            if (_pos < _s.Length) return _s[_pos];
            return '\0';
        }

        private string Remaining()
        {
            if (_pos < _s.Length) return _s.Substring(_pos);
            return "";
        }

        private string TryParseNumber()
        {
            int start = _pos;
            bool hasDigit = false;
            while (_pos < _s.Length && char.IsDigit(_s[_pos]))
            {
                _pos++;
                hasDigit = true;
            }
            if (_pos < _s.Length && _s[_pos] == '.')
            {
                _pos++;
                while (_pos < _s.Length && char.IsDigit(_s[_pos]))
                {
                    _pos++;
                    hasDigit = true;
                }
            }
            if (!hasDigit)
            {
                _pos = start;
                return null;
            }
            return _s.Substring(start, _pos - start);
        }

        private string TryParseFunctionName()
        {
            // поддержим sin, cos, tan, exp, ln
            string[] names = { "sin", "cos", "tan", "exp", "ln" };
            foreach (var n in names)
            {
                if (_pos + n.Length <= _s.Length)
                {
                    string sub = _s.Substring(_pos, n.Length);
                    if (sub == n)
                    {
                        _pos += n.Length;
                        return n;
                    }
                }
            }
            return null;
        }

        // Узлы дерева
        private abstract class Node
        {
            public abstract double Eval(double x);
        }

        private class NumNode : Node
        {
            double v;
            public NumNode(double vv) { v = vv; }
            public override double Eval(double x) => v;
        }

        private class VarNode : Node
        {
            public override double Eval(double x) => x;
        }

        private class UnaryMinusNode : Node
        {
            Node inner;
            public UnaryMinusNode(Node n) { inner = n; }
            public override double Eval(double x) => -inner.Eval(x);
        }

        private class BinaryNode : Node
        {
            Node a, b;
            char op;
            public BinaryNode(char op, Node left, Node right) { this.op = op; a = left; b = right; }
            public override double Eval(double x)
            {
                double A = a.Eval(x);
                double B = b.Eval(x);
                if (op == '+') return A + B;
                if (op == '-') return A - B;
                if (op == '*') return A * B;
                if (op == '/') return A / B;
                throw new Exception("Неизвестная бинарная операция: " + op);
            }
        }

        private class PowerNode : Node
        {
            Node a, b;
            public PowerNode(Node left, Node right) { a = left; b = right; }
            public override double Eval(double x)
            {
                double A = a.Eval(x);
                double B = b.Eval(x);
                return Math.Pow(A, B);
            }
        }

        private class FuncNode : Node
        {
            string name;
            Node arg;
            public FuncNode(string n, Node a) { name = n; arg = a; }
            public override double Eval(double x)
            {
                double v = arg.Eval(x);
                switch (name)
                {
                    case "sin": return Math.Sin(v);
                    case "cos": return Math.Cos(v);
                    case "tan": return Math.Tan(v);
                    case "exp": return Math.Exp(v);
                    case "ln": return Math.Log(v);
                }
                throw new Exception("Неизвестная функция: " + name);
            }
        }
    }
}
