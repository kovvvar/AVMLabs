﻿namespace SLAU_Solver
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelA = new System.Windows.Forms.Label();
            this.textA = new System.Windows.Forms.TextBox();
            this.labelF = new System.Windows.Forms.Label();
            this.textF = new System.Windows.Forms.TextBox();
            this.buttonGauss = new System.Windows.Forms.Button();
            this.buttonCholesky = new System.Windows.Forms.Button();
            this.textResult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Location = new System.Drawing.Point(12, 9);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(60, 13);
            this.labelA.TabIndex = 0;
            this.labelA.Text = "Матрица A:";
            // 
            // textA
            // 
            this.textA.Location = new System.Drawing.Point(15, 25);
            this.textA.Multiline = true;
            this.textA.Name = "textA";
            this.textA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textA.Size = new System.Drawing.Size(300, 100);
            this.textA.TabIndex = 1;
            this.textA.Text = "3 2 -1\r\n2 -2 4\r\n-1 0.5 -1";
            // 
            // labelF
            // 
            this.labelF.AutoSize = true;
            this.labelF.Location = new System.Drawing.Point(12, 138);
            this.labelF.Name = "labelF";
            this.labelF.Size = new System.Drawing.Size(49, 13);
            this.labelF.TabIndex = 2;
            this.labelF.Text = "Вектор f:";
            // 
            // textF
            // 
            this.textF.Location = new System.Drawing.Point(15, 154);
            this.textF.Multiline = true;
            this.textF.Name = "textF";
            this.textF.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textF.Size = new System.Drawing.Size(300, 60);
            this.textF.TabIndex = 3;
            this.textF.Text = "1\r\n-2\r\n0";
            // 
            // buttonGauss
            // 
            this.buttonGauss.Location = new System.Drawing.Point(340, 25);
            this.buttonGauss.Name = "buttonGauss";
            this.buttonGauss.Size = new System.Drawing.Size(140, 30);
            this.buttonGauss.TabIndex = 4;
            this.buttonGauss.Text = "Метод Гаусса";
            this.buttonGauss.UseVisualStyleBackColor = true;
            this.buttonGauss.Click += new System.EventHandler(this.buttonGauss_Click);
            // 
            // buttonCholesky
            // 
            this.buttonCholesky.Location = new System.Drawing.Point(340, 70);
            this.buttonCholesky.Name = "buttonCholesky";
            this.buttonCholesky.Size = new System.Drawing.Size(140, 30);
            this.buttonCholesky.TabIndex = 5;
            this.buttonCholesky.Text = "Метод Холецкого";
            this.buttonCholesky.UseVisualStyleBackColor = true;
            this.buttonCholesky.Click += new System.EventHandler(this.buttonCholesky_Click);
            // 
            // textResult
            // 
            this.textResult.Location = new System.Drawing.Point(15, 230);
            this.textResult.Multiline = true;
            this.textResult.Name = "textResult";
            this.textResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textResult.Size = new System.Drawing.Size(465, 150);
            this.textResult.TabIndex = 6;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(500, 400);
            this.Controls.Add(this.textResult);
            this.Controls.Add(this.buttonCholesky);
            this.Controls.Add(this.buttonGauss);
            this.Controls.Add(this.textF);
            this.Controls.Add(this.labelF);
            this.Controls.Add(this.textA);
            this.Controls.Add(this.labelA);
            this.Name = "Form1";
            this.Text = "Решение СЛАУ (Гаусс, Холецкий)";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.TextBox textA;
        private System.Windows.Forms.Label labelF;
        private System.Windows.Forms.TextBox textF;
        private System.Windows.Forms.Button buttonGauss;
        private System.Windows.Forms.Button buttonCholesky;
        private System.Windows.Forms.TextBox textResult;
    }
}
