﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace SLAU_Solver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
        }

        private void buttonGauss_Click(object sender, EventArgs e)
        {
            try
            {
                var (A, f) = ReadInput();
                double[] x = SolveGauss(A, f);
                double[] r = Residual(A, x, f);
                ShowResult("Метод Гаусса", x, r);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void buttonCholesky_Click(object sender, EventArgs e)
        {
            try
            {
                var (A, f) = ReadInput();
                double[] x = SolveCholesky(A, f);
                double[] r = Residual(A, x, f);
                ShowResult("Метод Холецкого", x, r);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private (double[,], double[]) ReadInput()
        {
            string[] linesA = textA.Text.Trim().Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            int n = linesA.Length;
            double[,] A = new double[n, n];
            for (int i = 0; i < n; i++)
            {
                string[] parts = linesA[i].Trim().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length != n)
                    throw new Exception($"В строке {i + 1} матрицы A найдено {parts.Length} элементов, ожидалось {n}");
                for (int j = 0; j < n; j++)
                    A[i, j] = double.Parse(parts[j], CultureInfo.InvariantCulture);
            }

            string[] linesF = textF.Text.Trim().Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            if (linesF.Length != n)
                throw new Exception("Размер вектора f должен совпадать с размером матрицы A");

            double[] f = new double[n];
            for (int i = 0; i < n; i++)
                f[i] = double.Parse(linesF[i], CultureInfo.InvariantCulture);

            return (A, f);
        }

        // Метод Гаусса
        private double[] SolveGauss(double[,] A, double[] f)
        {
            int n = f.Length;
            double[,] a = (double[,])A.Clone();
            double[] b = (double[])f.Clone();

            for (int k = 0; k < n - 1; k++)
            {
                if (Math.Abs(a[k, k]) < 1e-12)
                    throw new Exception("Нулевой элемент на диагонали (нужно перестановку строк)");

                for (int i = k + 1; i < n; i++)
                {
                    double factor = a[i, k] / a[k, k];
                    for (int j = k; j < n; j++)
                        a[i, j] -= factor * a[k, j];
                    b[i] -= factor * b[k];
                }
            }

            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0;
                for (int j = i + 1; j < n; j++)
                    sum += a[i, j] * x[j];
                x[i] = (b[i] - sum) / a[i, i];
            }
            return x;
        }

        // Метод Холецкого
        private double[] SolveCholesky(double[,] A, double[] f)
        {
            int n = f.Length;
            double[,] L = new double[n, n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    double sum = 0;
                    for (int k = 0; k < j; k++)
                        sum += L[i, k] * L[j, k];

                    if (i == j)
                        L[i, j] = Math.Sqrt(A[i, i] - sum);
                    else
                        L[i, j] = (A[i, j] - sum) / L[j, j];
                }
            }

            // Решаем L * y = f
            double[] y = new double[n];
            for (int i = 0; i < n; i++)
            {
                double sum = 0;
                for (int k = 0; k < i; k++)
                    sum += L[i, k] * y[k];
                y[i] = (f[i] - sum) / L[i, i];
            }

            // Решаем L^T * x = y
            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0;
                for (int k = i + 1; k < n; k++)
                    sum += L[k, i] * x[k];
                x[i] = (y[i] - sum) / L[i, i];
            }

            return x;
        }

        private double[] Residual(double[,] A, double[] x, double[] f)
        {
            int n = f.Length;
            double[] r = new double[n];
            for (int i = 0; i < n; i++)
            {
                double s = 0;
                for (int j = 0; j < n; j++)
                    s += A[i, j] * x[j];
                r[i] = s - f[i];
            }
            return r;
        }

        private void ShowResult(string method, double[] x, double[] r)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(method);
            sb.AppendLine("Решение x:");
            for (int i = 0; i < x.Length; i++)
                sb.AppendLine($"x{i + 1} = {x[i]:G10}");
            sb.AppendLine();
            sb.AppendLine("Вектор невязки r = A*x - f:");
            for (int i = 0; i < r.Length; i++)
                sb.AppendLine($"r{i + 1} = {r[i]:G10}");
            textResult.Text = sb.ToString();
        }
    }
}
