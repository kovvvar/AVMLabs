﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace avmlab7
{
    internal static class ExpressionEvaluator
    {
        private enum TokenType { Number, Variable, Operator, Function, LeftParen, RightParen }

        private sealed class Token
        {
            public TokenType Type { get; }
            public string Text { get; }
            public double Number { get; }

            public Token(TokenType type, string text, double number = 0)
            {
                Type = type;
                Text = text;
                Number = number;
            }
        }

        public static double Evaluate(string expression, double x)
        {
            if (string.IsNullOrWhiteSpace(expression))
                throw new ArgumentException("Пустое выражение.");

            var tokens = Tokenize(expression);
            var rpn = ToRpn(tokens);
            return EvalRpn(rpn, x);
        }

        private static List<Token> Tokenize(string s)
        {
            s = s.Trim();
            var tokens = new List<Token>();

            int i = 0;
            while (i < s.Length)
            {
                char c = s[i];

                if (char.IsWhiteSpace(c))
                {
                    i++;
                    continue;
                }

                // число (с точкой или запятой)
                if (char.IsDigit(c) || c == '.' || c == ',')
                {
                    int start = i;
                    while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '.' || s[i] == ','))
                        i++;

                    string numStr = s.Substring(start, i - start).Replace(',', '.');
                    if (!double.TryParse(numStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double val))
                        throw new ArgumentException($"Не удалось прочитать число: {numStr}");

                    tokens.Add(new Token(TokenType.Number, numStr, val));
                    continue;
                }

                // идентификатор: x или функция
                if (char.IsLetter(c))
                {
                    int start = i;
                    while (i < s.Length && char.IsLetter(s[i]))
                        i++;

                    string name = s.Substring(start, i - start).ToLowerInvariant();

                    if (name == "x")
                        tokens.Add(new Token(TokenType.Variable, "x"));
                    else
                        tokens.Add(new Token(TokenType.Function, name));

                    continue;
                }

                // скобки
                if (c == '(')
                {
                    tokens.Add(new Token(TokenType.LeftParen, "("));
                    i++;
                    continue;
                }
                if (c == ')')
                {
                    tokens.Add(new Token(TokenType.RightParen, ")"));
                    i++;
                    continue;
                }

                // операторы
                if ("+-*/^".IndexOf(c) >= 0)
                {
                    tokens.Add(new Token(TokenType.Operator, c.ToString()));
                    i++;
                    continue;
                }

                throw new ArgumentException($"Недопустимый символ: '{c}'");
            }

            // обработка унарного минуса: превращаем "-" в "u-" там, где нужно
            var fixedTokens = new List<Token>();
            for (int k = 0; k < tokens.Count; k++)
            {
                var t = tokens[k];
                if (t.Type == TokenType.Operator && t.Text == "-")
                {
                    bool unary = (k == 0) ||
                                 (tokens[k - 1].Type == TokenType.Operator) ||
                                 (tokens[k - 1].Type == TokenType.LeftParen);
                    if (unary)
                        fixedTokens.Add(new Token(TokenType.Function, "neg")); // neg(arg) = -arg
                    else
                        fixedTokens.Add(t);
                }
                else
                {
                    fixedTokens.Add(t);
                }
            }

            return fixedTokens;
        }

        private static List<Token> ToRpn(List<Token> tokens)
        {
            var output = new List<Token>();
            var stack = new Stack<Token>();

            foreach (var t in tokens)
            {
                switch (t.Type)
                {
                    case TokenType.Number:
                    case TokenType.Variable:
                        output.Add(t);
                        break;

                    case TokenType.Function:
                        stack.Push(t);
                        break;

                    case TokenType.Operator:
                        while (stack.Count > 0 &&
                               (stack.Peek().Type == TokenType.Operator || stack.Peek().Type == TokenType.Function) &&
                               (HasHigherPrecedence(stack.Peek(), t) ||
                                (SamePrecedence(stack.Peek(), t) && !IsRightAssociative(t))))
                        {
                            output.Add(stack.Pop());
                        }
                        stack.Push(t);
                        break;

                    case TokenType.LeftParen:
                        stack.Push(t);
                        break;

                    case TokenType.RightParen:
                        while (stack.Count > 0 && stack.Peek().Type != TokenType.LeftParen)
                            output.Add(stack.Pop());

                        if (stack.Count == 0)
                            throw new ArgumentException("Несогласованные скобки.");

                        stack.Pop(); // '('

                        // если перед скобками была функция — выгружаем её
                        if (stack.Count > 0 && stack.Peek().Type == TokenType.Function)
                            output.Add(stack.Pop());

                        break;
                }
            }

            while (stack.Count > 0)
            {
                if (stack.Peek().Type == TokenType.LeftParen || stack.Peek().Type == TokenType.RightParen)
                    throw new ArgumentException("Несогласованные скобки.");
                output.Add(stack.Pop());
            }

            return output;
        }

        private static double EvalRpn(List<Token> rpn, double x)
        {
            var st = new Stack<double>();

            foreach (var t in rpn)
            {
                if (t.Type == TokenType.Number)
                {
                    st.Push(t.Number);
                    continue;
                }
                if (t.Type == TokenType.Variable)
                {
                    st.Push(x);
                    continue;
                }

                if (t.Type == TokenType.Operator)
                {
                    if (st.Count < 2) throw new ArgumentException("Ошибка выражения (оператор без двух аргументов).");
                    double b = st.Pop();
                    double a = st.Pop();
                    st.Push(ApplyOperator(t.Text, a, b));
                    continue;
                }

                if (t.Type == TokenType.Function)
                {
                    if (st.Count < 1) throw new ArgumentException("Ошибка выражения (функция без аргумента).");
                    double a = st.Pop();
                    st.Push(ApplyFunction(t.Text, a));
                    continue;
                }

                throw new ArgumentException("Ошибка вычисления выражения.");
            }

            if (st.Count != 1)
                throw new ArgumentException("Ошибка выражения (лишние элементы).");

            return st.Pop();
        }

        private static double ApplyOperator(string op, double a, double b)
        {
            switch (op)
            {
                case "+": return a + b;
                case "-": return a - b;
                case "*": return a * b;
                case "/": return a / b;
                case "^": return Math.Pow(a, b);
                default: throw new ArgumentException($"Неизвестный оператор: {op}");
            }
        }

        private static double ApplyFunction(string fn, double a)
        {
            switch (fn)
            {
                case "neg": return -a;
                case "sin": return Math.Sin(a);
                case "cos": return Math.Cos(a);
                case "tan": return Math.Tan(a);
                case "exp": return Math.Exp(a);
                case "ln": return Math.Log(a);
                case "log": return Math.Log10(a);
                case "sqrt": return Math.Sqrt(a);
                case "abs": return Math.Abs(a);
                default: throw new ArgumentException($"Неизвестная функция: {fn}");
            }
        }

        private static int Precedence(Token t)
        {
            if (t.Type == TokenType.Function) return 5;
            if (t.Type != TokenType.Operator) return 0;

            switch (t.Text)
            {
                case "^": return 4;
                case "*":
                case "/": return 3;
                case "+":
                case "-": return 2;
                default: return 0;
            }
        }

        private static bool IsRightAssociative(Token t) => t.Type == TokenType.Operator && t.Text == "^";

        private static bool HasHigherPrecedence(Token stackTop, Token current) => Precedence(stackTop) > Precedence(current);

        private static bool SamePrecedence(Token a, Token b) => Precedence(a) == Precedence(b);
    }
}
