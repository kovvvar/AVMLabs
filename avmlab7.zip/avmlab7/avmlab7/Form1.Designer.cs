﻿namespace avmlab7
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblFx;
        private System.Windows.Forms.TextBox txtFx;

        private System.Windows.Forms.Label lblPhi;
        private System.Windows.Forms.TextBox txtPhi;

        private System.Windows.Forms.Label lblX0;
        private System.Windows.Forms.TextBox txtX0;

        private System.Windows.Forms.Label lblX1;
        private System.Windows.Forms.TextBox txtX1;

        private System.Windows.Forms.Label lblEps;
        private System.Windows.Forms.TextBox txtEps;

        private System.Windows.Forms.Button btnSecant;
        private System.Windows.Forms.Button btnSimple;

        private System.Windows.Forms.TextBox txtResult;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblFx = new System.Windows.Forms.Label();
            this.txtFx = new System.Windows.Forms.TextBox();
            this.lblPhi = new System.Windows.Forms.Label();
            this.txtPhi = new System.Windows.Forms.TextBox();
            this.lblX0 = new System.Windows.Forms.Label();
            this.txtX0 = new System.Windows.Forms.TextBox();
            this.lblX1 = new System.Windows.Forms.Label();
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.lblEps = new System.Windows.Forms.Label();
            this.txtEps = new System.Windows.Forms.TextBox();
            this.btnSecant = new System.Windows.Forms.Button();
            this.btnSimple = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblFx
            // 
            this.lblFx.AutoSize = true;
            this.lblFx.Location = new System.Drawing.Point(12, 12);
            this.lblFx.Name = "lblFx";
            this.lblFx.Size = new System.Drawing.Size(84, 13);
            this.lblFx.TabIndex = 0;
            this.lblFx.Text = "F(x) = 0, ввод F:";
            // 
            // txtFx
            // 
            this.txtFx.Location = new System.Drawing.Point(15, 30);
            this.txtFx.Name = "txtFx";
            this.txtFx.Size = new System.Drawing.Size(520, 20);
            this.txtFx.TabIndex = 1;
            this.txtFx.Text = "x^3 - x - 2";
            // 
            // lblPhi
            // 
            this.lblPhi.AutoSize = true;
            this.lblPhi.Location = new System.Drawing.Point(12, 58);
            this.lblPhi.Name = "lblPhi";
            this.lblPhi.Size = new System.Drawing.Size(177, 13);
            this.lblPhi.TabIndex = 2;
            this.lblPhi.Text = "Для простой итерации: x = φ(x):";
            // 
            // txtPhi
            // 
            this.txtPhi.Location = new System.Drawing.Point(15, 76);
            this.txtPhi.Name = "txtPhi";
            this.txtPhi.Size = new System.Drawing.Size(520, 20);
            this.txtPhi.TabIndex = 3;
            this.txtPhi.Text = "(x + 2)^(1/3)";
            // 
            // lblX0
            // 
            this.lblX0.AutoSize = true;
            this.lblX0.Location = new System.Drawing.Point(12, 110);
            this.lblX0.Name = "lblX0";
            this.lblX0.Size = new System.Drawing.Size(23, 13);
            this.lblX0.TabIndex = 4;
            this.lblX0.Text = "x0:";
            // 
            // txtX0
            // 
            this.txtX0.Location = new System.Drawing.Point(45, 107);
            this.txtX0.Name = "txtX0";
            this.txtX0.Size = new System.Drawing.Size(90, 20);
            this.txtX0.TabIndex = 5;
            this.txtX0.Text = "1";
            // 
            // lblX1
            // 
            this.lblX1.AutoSize = true;
            this.lblX1.Location = new System.Drawing.Point(150, 110);
            this.lblX1.Name = "lblX1";
            this.lblX1.Size = new System.Drawing.Size(23, 13);
            this.lblX1.TabIndex = 6;
            this.lblX1.Text = "x1:";
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(183, 107);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(90, 20);
            this.txtX1.TabIndex = 7;
            this.txtX1.Text = "2";
            // 
            // lblEps
            // 
            this.lblEps.AutoSize = true;
            this.lblEps.Location = new System.Drawing.Point(295, 110);
            this.lblEps.Name = "lblEps";
            this.lblEps.Size = new System.Drawing.Size(24, 13);
            this.lblEps.TabIndex = 8;
            this.lblEps.Text = "ε =";
            // 
            // txtEps
            // 
            this.txtEps.Location = new System.Drawing.Point(325, 107);
            this.txtEps.Name = "txtEps";
            this.txtEps.Size = new System.Drawing.Size(90, 20);
            this.txtEps.TabIndex = 9;
            this.txtEps.Text = "1e-6";
            // 
            // btnSecant
            // 
            this.btnSecant.Location = new System.Drawing.Point(15, 140);
            this.btnSecant.Name = "btnSecant";
            this.btnSecant.Size = new System.Drawing.Size(200, 30);
            this.btnSecant.TabIndex = 10;
            this.btnSecant.Text = "Метод секущих";
            this.btnSecant.UseVisualStyleBackColor = true;
            this.btnSecant.Click += new System.EventHandler(this.BtnSecant_Click);
            // 
            // btnSimple
            // 
            this.btnSimple.Location = new System.Drawing.Point(230, 140);
            this.btnSimple.Name = "btnSimple";
            this.btnSimple.Size = new System.Drawing.Size(305, 30);
            this.btnSimple.TabIndex = 11;
            this.btnSimple.Text = "Метод простой итерации (x = φ(x))";
            this.btnSimple.UseVisualStyleBackColor = true;
            this.btnSimple.Click += new System.EventHandler(this.BtnSimple_Click);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(15, 185);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResult.Size = new System.Drawing.Size(520, 250);
            this.txtResult.TabIndex = 12;
            this.txtResult.Font = new System.Drawing.Font("Consolas", 9F);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(552, 450);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnSimple);
            this.Controls.Add(this.btnSecant);
            this.Controls.Add(this.txtEps);
            this.Controls.Add(this.lblEps);
            this.Controls.Add(this.txtX1);
            this.Controls.Add(this.lblX1);
            this.Controls.Add(this.txtX0);
            this.Controls.Add(this.lblX0);
            this.Controls.Add(this.txtPhi);
            this.Controls.Add(this.lblPhi);
            this.Controls.Add(this.txtFx);
            this.Controls.Add(this.lblFx);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Решение F(x)=0: секущие и простая итерация";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
