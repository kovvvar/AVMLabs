﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace avmlab7

{
    public partial class Form1 : Form
    {
        private const int MaxIter = 10000;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSecant_Click(object sender, EventArgs e)
        {
            try
            {
                var input = ReadInputs(requirePhi: false);

                Func<double, double> f = x => ExpressionEvaluator.Evaluate(input.fx, x);

                var res = SecantMethod(f, input.x0, input.x1, input.eps, MaxIter);

                txtResult.Text = FormatResult(
                    methodName: "Метод секущих",
                    fx: input.fx,
                    phi: null,
                    res: res,
                    f: f
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSimple_Click(object sender, EventArgs e)
        {
            try
            {
                var input = ReadInputs(requirePhi: true);

                Func<double, double> f = x => ExpressionEvaluator.Evaluate(input.fx, x);
                Func<double, double> phi = x => ExpressionEvaluator.Evaluate(input.phi, x);

                var res = SimpleIterationMethod(f, phi, input.x0, input.eps, MaxIter);

                txtResult.Text = FormatResult(
                    methodName: "Метод простой итерации",
                    fx: input.fx,
                    phi: input.phi,
                    res: res,
                    f: f
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private (string fx, string phi, double x0, double x1, double eps) ReadInputs(bool requirePhi)
        {
            string fx = txtFx.Text.Trim();
            if (string.IsNullOrWhiteSpace(fx))
                throw new Exception("Введите F(x). Пример: x^3 - x - 2");

            string phi = txtPhi.Text.Trim();
            if (requirePhi && string.IsNullOrWhiteSpace(phi))
                throw new Exception("Введите φ(x) для метода простой итерации.");

            double x0 = ReadDouble(txtX0.Text, "x0");
            double x1 = ReadDouble(txtX1.Text, "x1");
            double eps = ReadDouble(txtEps.Text, "ε");

            if (eps <= 0) throw new Exception("ε должно быть > 0.");

            return (fx, phi, x0, x1, eps);
        }

        private double ReadDouble(string s, string name)
        {
            s = s.Trim().Replace(',', '.');
            if (!double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out double v))
                throw new Exception($"Не удалось прочитать {name}.");

            return v;
        }

        private string FormatResult(
            string methodName,
            string fx,
            string phi,
            (double root, int iterations, bool converged, string note) res,
            Func<double, double> f)
        {
            var sb = new StringBuilder();
            sb.AppendLine(methodName);
            sb.AppendLine(new string('-', 50));
            sb.AppendLine($"F(x): {fx}");
            if (!string.IsNullOrWhiteSpace(phi))
                sb.AppendLine($"φ(x): {phi}");
            sb.AppendLine();

            sb.AppendLine($"Статус: {(res.converged ? "сошёлся" : "не сошёлся")}");
            if (!string.IsNullOrWhiteSpace(res.note))
                sb.AppendLine($"Примечание: {res.note}");

            sb.AppendLine($"Итераций: {res.iterations}");
            sb.AppendLine($"x ≈ {res.root.ToString("0.###############", CultureInfo.InvariantCulture)}");
            sb.AppendLine($"|F(x)| = {Math.Abs(f(res.root)).ToString("0.000000E+0", CultureInfo.InvariantCulture)}");

            return sb.ToString();
        }

        // ===================== МЕТОД СЕКУЩИХ =====================
        // x_{k+1} = x_k - F(x_k) * (x_k - x_{k-1}) / (F(x_k) - F(x_{k-1}))
        private (double root, int iterations, bool converged, string note) SecantMethod(
            Func<double, double> f,
            double x0,
            double x1,
            double eps,
            int maxIter)
        {
            double f0 = f(x0);
            double f1 = f(x1);

            for (int iter = 1; iter <= maxIter; iter++)
            {
                double denom = f1 - f0;
                if (Math.Abs(denom) < 1e-15)
                    return (x1, iter, false, "Деление на число близкое к 0 (F(x1) - F(x0)).");

                double x2 = x1 - f1 * (x1 - x0) / denom;

                if (Math.Abs(x2 - x1) < eps || Math.Abs(f(x2)) < eps)
                    return (x2, iter, true, null);

                x0 = x1;
                f0 = f1;
                x1 = x2;
                f1 = f(x1);
            }

            return (x1, maxIter, false, "Превышено максимальное число итераций.");
        }

        // ===================== ПРОСТАЯ ИТЕРАЦИЯ =====================
        // x_{k+1} = φ(x_k)
        private (double root, int iterations, bool converged, string note) SimpleIterationMethod(
            Func<double, double> f,
            Func<double, double> phi,
            double x0,
            double eps,
            int maxIter)
        {
            double x = x0;

            for (int iter = 1; iter <= maxIter; iter++)
            {
                double xNext = phi(x);

                if (double.IsNaN(xNext) || double.IsInfinity(xNext))
                    return (x, iter, false, "φ(x) дала недопустимое значение (NaN/Infinity).");

                if (Math.Abs(xNext - x) < eps || Math.Abs(f(xNext)) < eps)
                    return (xNext, iter, true, null);

                x = xNext;
            }

            return (x, maxIter, false, "Превышено максимальное число итераций. Возможно, φ(x) выбрана неудачно.");
        }
    }
}
