﻿namespace avmlab8._1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.NumericUpDown nudN;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.DataGridView dgvA;
        private System.Windows.Forms.DataGridView dgvInv;
        private System.Windows.Forms.Button btnInvert;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblInv;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.nudN = new System.Windows.Forms.NumericUpDown();
            this.btnCreate = new System.Windows.Forms.Button();
            this.dgvA = new System.Windows.Forms.DataGridView();
            this.dgvInv = new System.Windows.Forms.DataGridView();
            this.btnInvert = new System.Windows.Forms.Button();
            this.lblA = new System.Windows.Forms.Label();
            this.lblInv = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInv)).BeginInit();
            this.SuspendLayout();
            // 
            // nudN
            // 
            this.nudN.Location = new System.Drawing.Point(12, 12);
            this.nudN.Maximum = new decimal(new int[] { 12, 0, 0, 0 });
            this.nudN.Minimum = new decimal(new int[] { 2, 0, 0, 0 });
            this.nudN.Name = "nudN";
            this.nudN.Size = new System.Drawing.Size(60, 20);
            this.nudN.TabIndex = 0;
            this.nudN.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(90, 10);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(140, 23);
            this.btnCreate.TabIndex = 1;
            this.btnCreate.Text = "Создать матрицу";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.BtnCreate_Click);
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(12, 45);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(54, 13);
            this.lblA.TabIndex = 2;
            this.lblA.Text = "Матрица A";
            // 
            // dgvA
            // 
            this.dgvA.AllowUserToAddRows = false;
            this.dgvA.AllowUserToDeleteRows = false;
            this.dgvA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvA.Location = new System.Drawing.Point(12, 65);
            this.dgvA.Name = "dgvA";
            this.dgvA.RowHeadersVisible = false;
            this.dgvA.Size = new System.Drawing.Size(360, 300);
            this.dgvA.TabIndex = 3;
            // 
            // btnInvert
            // 
            this.btnInvert.Location = new System.Drawing.Point(12, 375);
            this.btnInvert.Name = "btnInvert";
            this.btnInvert.Size = new System.Drawing.Size(218, 30);
            this.btnInvert.TabIndex = 4;
            this.btnInvert.Text = "Найти обратную (Гаусс)";
            this.btnInvert.UseVisualStyleBackColor = true;
            this.btnInvert.Click += new System.EventHandler(this.BtnInvert_Click);
            // 
            // lblInv
            // 
            this.lblInv.AutoSize = true;
            this.lblInv.Location = new System.Drawing.Point(390, 45);
            this.lblInv.Name = "lblInv";
            this.lblInv.Size = new System.Drawing.Size(90, 13);
            this.lblInv.TabIndex = 5;
            this.lblInv.Text = "Обратная A^(-1)";
            // 
            // dgvInv
            // 
            this.dgvInv.AllowUserToAddRows = false;
            this.dgvInv.AllowUserToDeleteRows = false;
            this.dgvInv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvInv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInv.Location = new System.Drawing.Point(390, 65);
            this.dgvInv.Name = "dgvInv";
            this.dgvInv.RowHeadersVisible = false;
            this.dgvInv.Size = new System.Drawing.Size(360, 300);
            this.dgvInv.TabIndex = 6;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(770, 420);
            this.Controls.Add(this.dgvInv);
            this.Controls.Add(this.lblInv);
            this.Controls.Add(this.btnInvert);
            this.Controls.Add(this.dgvA);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.nudN);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Обратная матрица методом Гаусса";
            ((System.ComponentModel.ISupportInitialize)(this.nudN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
