﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace avmlab8._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            BtnCreate_Click(this, EventArgs.Empty);
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            int n = (int)nudN.Value;

            SetupGrid(dgvA, n);
            SetupGrid(dgvInv, n);

            // очистить значения
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    dgvA.Rows[i].Cells[j].Value = "0";
                    dgvInv.Rows[i].Cells[j].Value = "";
                }
        }

        private void SetupGrid(DataGridView dgv, int n)
        {
            dgv.Columns.Clear();
            dgv.Rows.Clear();
            dgv.RowHeadersVisible = false;

            for (int j = 0; j < n; j++)
            {
                var col = new DataGridViewTextBoxColumn();
                col.HeaderText = (j + 1).ToString();
                dgv.Columns.Add(col);
            }

            dgv.Rows.Add(n);
        }

        private void BtnInvert_Click(object sender, EventArgs e)
        {
            try
            {
                double[,] A = ReadMatrix(dgvA);
                double[,] inv = InvertByGauss(A);

                WriteMatrix(dgvInv, inv);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private double[,] ReadMatrix(DataGridView dgv)
        {
            int n = dgv.ColumnCount;
            if (n == 0 || dgv.RowCount != n)
                throw new Exception("Сначала создайте матрицу нужного размера.");

            double[,] A = new double[n, n];
            var ci = CultureInfo.CurrentCulture;
            var inv = CultureInfo.InvariantCulture;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    object v = dgv.Rows[i].Cells[j].Value;
                    if (v == null)
                        throw new Exception($"A[{i + 1},{j + 1}] не заполнен.");

                    string s = v.ToString().Trim();
                    if (!double.TryParse(s, NumberStyles.Any, ci, out double x) &&
                        !double.TryParse(s, NumberStyles.Any, inv, out x))
                    {
                        throw new Exception($"Некорректное число в A[{i + 1},{j + 1}]: '{s}'");
                    }

                    A[i, j] = x;
                }
            }

            return A;
        }

        private void WriteMatrix(DataGridView dgv, double[,] M)
        {
            int n = M.GetLength(0);
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    dgv.Rows[i].Cells[j].Value = M[i, j].ToString("0.######", CultureInfo.InvariantCulture);
        }

        // Обратная матрица методом Гаусса: [A | I] -> [I | A^{-1}]
        // Используется частичный выбор главного элемента (по столбцу).
        private double[,] InvertByGauss(double[,] A)
        {
            int n = A.GetLength(0);
            if (A.GetLength(1) != n) throw new Exception("Матрица должна быть квадратной.");

            // расширенная матрица aug размера n x (2n)
            double[,] aug = new double[n, 2 * n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                    aug[i, j] = A[i, j];

                for (int j = 0; j < n; j++)
                    aug[i, n + j] = (i == j) ? 1.0 : 0.0;
            }

            // Прямой ход + нормализация ведущей строки
            for (int col = 0; col < n; col++)
            {
                // 1) выбор главного элемента (pivot) в текущем столбце
                int pivotRow = col;
                double maxAbs = Math.Abs(aug[col, col]);
                for (int r = col + 1; r < n; r++)
                {
                    double val = Math.Abs(aug[r, col]);
                    if (val > maxAbs)
                    {
                        maxAbs = val;
                        pivotRow = r;
                    }
                }

                if (maxAbs < 1e-12)
                    throw new Exception("Матрица вырожденная (обратной не существует).");

                // 2) перестановка строк
                if (pivotRow != col)
                    SwapRows(aug, pivotRow, col);

                // 3) делим ведущую строку, чтобы pivot стал равен 1
                double pivot = aug[col, col];
                for (int j = 0; j < 2 * n; j++)
                    aug[col, j] /= pivot;

                // 4) зануляем элементы в этом столбце во всех остальных строках
                for (int r = 0; r < n; r++)
                {
                    if (r == col) continue;

                    double factor = aug[r, col]; // т.к. ведущая строка уже нормирована
                    if (Math.Abs(factor) < 1e-15) continue;

                    for (int j = 0; j < 2 * n; j++)
                        aug[r, j] -= factor * aug[col, j];
                }
            }

            // правая часть aug теперь A^{-1}
            double[,] inv = new double[n, n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    inv[i, j] = aug[i, n + j];

            return inv;
        }

        private void SwapRows(double[,] m, int r1, int r2)
        {
            int cols = m.GetLength(1);
            for (int j = 0; j < cols; j++)
            {
                double tmp = m[r1, j];
                m[r1, j] = m[r2, j];
                m[r2, j] = tmp;
            }
        }
    }
}
