﻿using System.Windows.Forms.DataVisualization.Charting;

namespace SlauIterative
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelA = new System.Windows.Forms.Label();
            this.textA = new System.Windows.Forms.TextBox();
            this.labelF = new System.Windows.Forms.Label();
            this.textF = new System.Windows.Forms.TextBox();
            this.labelX0 = new System.Windows.Forms.Label();
            this.textX0 = new System.Windows.Forms.TextBox();
            this.labelEps = new System.Windows.Forms.Label();
            this.textEps = new System.Windows.Forms.TextBox();
            this.labelMax = new System.Windows.Forms.Label();
            this.textMaxIter = new System.Windows.Forms.TextBox();
            this.buttonJacobi = new System.Windows.Forms.Button();
            this.buttonSD = new System.Windows.Forms.Button();
            this.textResult = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Location = new System.Drawing.Point(12, 9);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(60, 13);
            this.labelA.TabIndex = 0;
            this.labelA.Text = "Матрица A:";
            // 
            // textA
            // 
            this.textA.Location = new System.Drawing.Point(15, 25);
            this.textA.Multiline = true;
            this.textA.Name = "textA";
            this.textA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textA.Size = new System.Drawing.Size(310, 100);
            this.textA.TabIndex = 1;
            this.textA.Text = "4 1 1\r\n1 3 0\r\n1 0 2";
            // 
            // labelF
            // 
            this.labelF.AutoSize = true;
            this.labelF.Location = new System.Drawing.Point(12, 135);
            this.labelF.Name = "labelF";
            this.labelF.Size = new System.Drawing.Size(49, 13);
            this.labelF.TabIndex = 2;
            this.labelF.Text = "Вектор f:";
            // 
            // textF
            // 
            this.textF.Location = new System.Drawing.Point(15, 151);
            this.textF.Multiline = true;
            this.textF.Name = "textF";
            this.textF.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textF.Size = new System.Drawing.Size(310, 60);
            this.textF.TabIndex = 3;
            this.textF.Text = "1\r\n2\r\n3";
            // 
            // labelX0
            // 
            this.labelX0.AutoSize = true;
            this.labelX0.Location = new System.Drawing.Point(12, 218);
            this.labelX0.Name = "labelX0";
            this.labelX0.Size = new System.Drawing.Size(110, 13);
            this.labelX0.TabIndex = 4;
            this.labelX0.Text = "Нач. приближение x0:";
            // 
            // textX0
            // 
            this.textX0.Location = new System.Drawing.Point(15, 234);
            this.textX0.Multiline = true;
            this.textX0.Name = "textX0";
            this.textX0.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textX0.Size = new System.Drawing.Size(310, 60);
            this.textX0.TabIndex = 5;
            this.textX0.Text = "0\r\n0\r\n0";
            // 
            // labelEps
            // 
            this.labelEps.AutoSize = true;
            this.labelEps.Location = new System.Drawing.Point(12, 305);
            this.labelEps.Name = "labelEps";
            this.labelEps.Size = new System.Drawing.Size(65, 13);
            this.labelEps.TabIndex = 6;
            this.labelEps.Text = "Точность ε:";
            // 
            // textEps
            // 
            this.textEps.Location = new System.Drawing.Point(83, 302);
            this.textEps.Name = "textEps";
            this.textEps.Size = new System.Drawing.Size(70, 20);
            this.textEps.TabIndex = 7;
            this.textEps.Text = "0.0001";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(170, 305);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(95, 13);
            this.labelMax.TabIndex = 8;
            this.labelMax.Text = "Макс. итераций:";
            // 
            // textMaxIter
            // 
            this.textMaxIter.Location = new System.Drawing.Point(271, 302);
            this.textMaxIter.Name = "textMaxIter";
            this.textMaxIter.Size = new System.Drawing.Size(54, 20);
            this.textMaxIter.TabIndex = 9;
            this.textMaxIter.Text = "1000";
            // 
            // buttonJacobi
            // 
            this.buttonJacobi.Location = new System.Drawing.Point(350, 25);
            this.buttonJacobi.Name = "buttonJacobi";
            this.buttonJacobi.Size = new System.Drawing.Size(150, 30);
            this.buttonJacobi.TabIndex = 10;
            this.buttonJacobi.Text = "Метод Якоби";
            this.buttonJacobi.UseVisualStyleBackColor = true;
            this.buttonJacobi.Click += new System.EventHandler(this.buttonJacobi_Click);
            // 
            // buttonSD
            // 
            this.buttonSD.Location = new System.Drawing.Point(350, 65);
            this.buttonSD.Name = "buttonSD";
            this.buttonSD.Size = new System.Drawing.Size(150, 30);
            this.buttonSD.TabIndex = 11;
            this.buttonSD.Text = "Наискор. спуск";
            this.buttonSD.UseVisualStyleBackColor = true;
            this.buttonSD.Click += new System.EventHandler(this.buttonSD_Click);
            // 
            // textResult
            // 
            this.textResult.Location = new System.Drawing.Point(350, 110);
            this.textResult.Multiline = true;
            this.textResult.Name = "textResult";
            this.textResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textResult.Size = new System.Drawing.Size(300, 212);
            this.textResult.TabIndex = 12;
            // 
            // chart1
            // 
            ChartArea area = new ChartArea("Area1");
            area.AxisX.Title = "Итерация k";
            area.AxisY.Title = "||r_k||";
            this.chart1.ChartAreas.Add(area);
            this.chart1.Location = new System.Drawing.Point(15, 335);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(635, 220);
            this.chart1.TabIndex = 13;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(670, 570);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.textResult);
            this.Controls.Add(this.buttonSD);
            this.Controls.Add(this.buttonJacobi);
            this.Controls.Add(this.textMaxIter);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.textEps);
            this.Controls.Add(this.labelEps);
            this.Controls.Add(this.textX0);
            this.Controls.Add(this.labelX0);
            this.Controls.Add(this.textF);
            this.Controls.Add(this.labelF);
            this.Controls.Add(this.textA);
            this.Controls.Add(this.labelA);
            this.Name = "Form1";
            this.Text = "Решение СЛАУ (Якоби, Наискорейший спуск)";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.TextBox textA;
        private System.Windows.Forms.Label labelF;
        private System.Windows.Forms.TextBox textF;
        private System.Windows.Forms.Label labelX0;
        private System.Windows.Forms.TextBox textX0;
        private System.Windows.Forms.Label labelEps;
        private System.Windows.Forms.TextBox textEps;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.TextBox textMaxIter;
        private System.Windows.Forms.Button buttonJacobi;
        private System.Windows.Forms.Button buttonSD;
        private System.Windows.Forms.TextBox textResult;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}
