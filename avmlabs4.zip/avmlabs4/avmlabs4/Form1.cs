﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace SlauIterative
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            PrepareChart();
        }

        private void PrepareChart()
        {
            chart1.Series.Clear();
            var s = new Series("residual");
            s.ChartType = SeriesChartType.Line;
            s.BorderWidth = 2;
            chart1.Series.Add(s);
        }

        // ===== КНОПКИ =====

        private void buttonJacobi_Click(object sender, EventArgs e)
        {
            try
            {
                var (A, f, x0, eps, maxIter) = ReadInput();
                PrepareChart();

                double[] x;
                int iters;
                var residuals = Jacobi(A, f, x0, eps, maxIter, out x, out iters);

                ShowResults("Метод Якоби", x, residuals, iters);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void buttonSD_Click(object sender, EventArgs e)
        {
            try
            {
                var (A, f, x0, eps, maxIter) = ReadInput();
                PrepareChart();

                double[] x;
                int iters;
                var residuals = SteepestDescent(A, f, x0, eps, maxIter, out x, out iters);

                ShowResults("Метод наискорейшего спуска", x, residuals, iters);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        // ===== ВВОД =====

        private (double[,], double[], double[], double, int) ReadInput()
        {
            // Матрица A
            string[] linesA = textA.Text.Trim().Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            int n = linesA.Length;
            double[,] A = new double[n, n];
            for (int i = 0; i < n; i++)
            {
                string[] parts = linesA[i].Trim().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length != n)
                    throw new Exception($"В строке {i + 1} матрицы A {parts.Length} элементов, ожидалось {n}");
                for (int j = 0; j < n; j++)
                    A[i, j] = double.Parse(parts[j], CultureInfo.InvariantCulture);
            }

            // Вектор f
            string[] linesF = textF.Text.Trim().Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            if (linesF.Length != n) throw new Exception("Размер вектора f должен совпадать с размером A");
            double[] f = new double[n];
            for (int i = 0; i < n; i++)
                f[i] = double.Parse(linesF[i], CultureInfo.InvariantCulture);

            // x0
            string[] linesX0 = textX0.Text.Trim().Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            if (linesX0.Length != n) throw new Exception("Размер вектора x0 должен совпадать с размером A");
            double[] x0 = new double[n];
            for (int i = 0; i < n; i++)
                x0[i] = double.Parse(linesX0[i], CultureInfo.InvariantCulture);

            // eps и maxIter
            if (!double.TryParse(textEps.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double eps) || eps <= 0)
                throw new Exception("Некорректная точность ε");
            if (!int.TryParse(textMaxIter.Text.Trim(), out int maxIter) || maxIter <= 0)
                throw new Exception("Некорректное число итераций");

            return (A, f, x0, eps, maxIter);
        }

        // ===== МЕТОД ЯКОБИ =====
        private double[] Jacobi(double[,] A, double[] f, double[] x0, double eps, int maxIter, out double[] x, out int iters)
        {
            int n = f.Length;
            x = (double[])x0.Clone();
            double[] xNew = new double[n];

            var residuals = new System.Collections.Generic.List<double>();

            for (iters = 0; iters < maxIter; iters++)
            {
                for (int i = 0; i < n; i++)
                {
                    double sum = 0.0;
                    for (int j = 0; j < n; j++)
                    {
                        if (j == i) continue;
                        sum += A[i, j] * x[j];
                    }
                    if (Math.Abs(A[i, i]) < 1e-14) throw new Exception("Нулевой диагональный элемент в A (Метод Якоби)");
                    xNew[i] = (f[i] - sum) / A[i, i];
                }

                // невязка r = A xNew - f
                double[] r = Residual(A, xNew, f);
                double norm = Norm2(r);
                residuals.Add(norm);
                chart1.Series[0].Points.AddXY(iters + 1, norm);

                x = (double[])xNew.Clone();
                if (norm < eps) break;
            }

            return residuals.ToArray();
        }

        // ===== МЕТОД НАИСКОРЕЙШЕГО СПУСКА =====
        // Требует A симметричную положительно определённую для гарантированной сходимости.
        private double[] SteepestDescent(double[,] A, double[] f, double[] x0, double eps, int maxIter, out double[] x, out int iters)
        {
            int n = f.Length;
            x = (double[])x0.Clone();

            var residuals = new System.Collections.Generic.List<double>();

            for (iters = 0; iters < maxIter; iters++)
            {
                double[] r = Residual(A, x, f); // r_k = A x_k - f
                double nom = Dot(r, r);

                // вычисляем A r
                double[] Ar = Mul(A, r);
                double denom = Dot(r, Ar);

                if (Math.Abs(denom) < 1e-20)
                    throw new Exception("Деление на ноль в шаге метода наискорейшего спуска (проверьте SPD инициализацию).");

                double alpha = nom / denom;   // шаг
                // x_{k+1} = x_k - alpha * r_k
                for (int i = 0; i < n; i++)
                    x[i] = x[i] - alpha * r[i];

                double norm = Math.Sqrt(nom); // ||r_k||
                residuals.Add(norm);
                chart1.Series[0].Points.AddXY(iters + 1, norm);

                if (norm < eps) break;
            }

            return residuals.ToArray();
        }

        // ===== СЛУЖЕБНЫЕ ФУНКЦИИ =====

        private double[] Mul(double[,] A, double[] x)
        {
            int n = x.Length;
            double[] y = new double[n];
            for (int i = 0; i < n; i++)
            {
                double s = 0;
                for (int j = 0; j < n; j++)
                    s += A[i, j] * x[j];
                y[i] = s;
            }
            return y;
        }

        private double[] Residual(double[,] A, double[] x, double[] f)
        {
            int n = f.Length;
            double[] r = new double[n];
            for (int i = 0; i < n; i++)
            {
                double s = 0;
                for (int j = 0; j < n; j++)
                    s += A[i, j] * x[j];
                r[i] = s - f[i];
            }
            return r;
        }

        private double Dot(double[] a, double[] b)
        {
            double s = 0;
            for (int i = 0; i < a.Length; i++) s += a[i] * b[i];
            return s;
        }

        private double Norm2(double[] v) => Math.Sqrt(Dot(v, v));

        private void ShowResults(string title, double[] x, double[] residuals, int iters)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(title);
            sb.AppendLine("Решение x:");
            for (int i = 0; i < x.Length; i++)
                sb.AppendLine($"x{i + 1} = {x[i]:G10}");
            if (residuals.Length > 0)
            {
                sb.AppendLine();
                sb.AppendLine("Нормы невязки по итерациям:");
                for (int k = 0; k < residuals.Length; k++)
                    sb.AppendLine($"k={k + 1}: ||r|| = {residuals[k]:G10}");
                sb.AppendLine();
                sb.AppendLine($"Достигнутая точность на итерации: {residuals.Length} (||r|| = {residuals[residuals.Length - 1]:G10})");
            }
            textResult.Text = sb.ToString();
        }
    }
}
