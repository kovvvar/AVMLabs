﻿namespace EigenvaluesWinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.nudN = new System.Windows.Forms.NumericUpDown();
            this.btnCreateMatrix = new System.Windows.Forms.Button();
            this.dgvA = new System.Windows.Forms.DataGridView();
            this.txtEps = new System.Windows.Forms.TextBox();
            this.lblN = new System.Windows.Forms.Label();
            this.lblEps = new System.Windows.Forms.Label();
            this.groupBoxMethod = new System.Windows.Forms.GroupBox();
            this.rbPower = new System.Windows.Forms.RadioButton();
            this.rbJacobi = new System.Windows.Forms.RadioButton();
            this.btnSolve = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.lblResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvA)).BeginInit();
            this.groupBoxMethod.SuspendLayout();
            this.SuspendLayout();
            // 
            // nudN
            // 
            this.nudN.Location = new System.Drawing.Point(82, 12);
            this.nudN.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudN.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudN.Name = "nudN";
            this.nudN.Size = new System.Drawing.Size(60, 20);
            this.nudN.TabIndex = 0;
            this.nudN.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // btnCreateMatrix
            // 
            this.btnCreateMatrix.Location = new System.Drawing.Point(160, 10);
            this.btnCreateMatrix.Name = "btnCreateMatrix";
            this.btnCreateMatrix.Size = new System.Drawing.Size(120, 23);
            this.btnCreateMatrix.TabIndex = 1;
            this.btnCreateMatrix.Text = "Создать матрицу";
            this.btnCreateMatrix.UseVisualStyleBackColor = true;
            this.btnCreateMatrix.Click += new System.EventHandler(this.BtnCreateMatrix_Click);
            // 
            // dgvA
            // 
            this.dgvA.AllowUserToAddRows = false;
            this.dgvA.AllowUserToDeleteRows = false;
            this.dgvA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvA.Location = new System.Drawing.Point(12, 110);
            this.dgvA.Name = "dgvA";
            this.dgvA.RowHeadersVisible = false;
            this.dgvA.Size = new System.Drawing.Size(430, 250);
            this.dgvA.TabIndex = 2;
            // 
            // txtEps
            // 
            this.txtEps.Location = new System.Drawing.Point(82, 44);
            this.txtEps.Name = "txtEps";
            this.txtEps.Size = new System.Drawing.Size(80, 20);
            this.txtEps.TabIndex = 3;
            this.txtEps.Text = "0,0001";
            // 
            // lblN
            // 
            this.lblN.AutoSize = true;
            this.lblN.Location = new System.Drawing.Point(12, 14);
            this.lblN.Name = "lblN";
            this.lblN.Size = new System.Drawing.Size(59, 13);
            this.lblN.TabIndex = 4;
            this.lblN.Text = "Размер n:";
            // 
            // lblEps
            // 
            this.lblEps.AutoSize = true;
            this.lblEps.Location = new System.Drawing.Point(12, 47);
            this.lblEps.Name = "lblEps";
            this.lblEps.Size = new System.Drawing.Size(64, 13);
            this.lblEps.TabIndex = 5;
            this.lblEps.Text = "Точность ε:";
            // 
            // groupBoxMethod
            // 
            this.groupBoxMethod.Controls.Add(this.rbPower);
            this.groupBoxMethod.Controls.Add(this.rbJacobi);
            this.groupBoxMethod.Location = new System.Drawing.Point(160, 35);
            this.groupBoxMethod.Name = "groupBoxMethod";
            this.groupBoxMethod.Size = new System.Drawing.Size(260, 60);
            this.groupBoxMethod.TabIndex = 6;
            this.groupBoxMethod.TabStop = false;
            this.groupBoxMethod.Text = "Метод";
            // 
            // rbPower
            // 
            this.rbPower.AutoSize = true;
            this.rbPower.Checked = true;
            this.rbPower.Location = new System.Drawing.Point(10, 20);
            this.rbPower.Name = "rbPower";
            this.rbPower.Size = new System.Drawing.Size(217, 17);
            this.rbPower.TabIndex = 0;
            this.rbPower.TabStop = true;
            this.rbPower.Text = "Прямая итерация (степенной метод)";
            this.rbPower.UseVisualStyleBackColor = true;
            // 
            // rbJacobi
            // 
            this.rbJacobi.AutoSize = true;
            this.rbJacobi.Location = new System.Drawing.Point(10, 38);
            this.rbJacobi.Name = "rbJacobi";
            this.rbJacobi.Size = new System.Drawing.Size(160, 17);
            this.rbJacobi.TabIndex = 1;
            this.rbJacobi.Text = "Метод вращений (Якоби)";
            this.rbJacobi.UseVisualStyleBackColor = true;
            // 
            // btnSolve
            // 
            this.btnSolve.Location = new System.Drawing.Point(12, 370);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(120, 30);
            this.btnSolve.TabIndex = 7;
            this.btnSolve.Text = "Вычислить";
            this.btnSolve.UseVisualStyleBackColor = true;
            this.btnSolve.Click += new System.EventHandler(this.BtnSolve_Click);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(450, 35);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResult.Size = new System.Drawing.Size(330, 425);
            this.txtResult.TabIndex = 8;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(447, 15);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(62, 13);
            this.lblResult.TabIndex = 9;
            this.lblResult.Text = "Результат:";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 480);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnSolve);
            this.Controls.Add(this.groupBoxMethod);
            this.Controls.Add(this.lblEps);
            this.Controls.Add(this.lblN);
            this.Controls.Add(this.txtEps);
            this.Controls.Add(this.dgvA);
            this.Controls.Add(this.btnCreateMatrix);
            this.Controls.Add(this.nudN);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Собственные числа матрицы";
            ((System.ComponentModel.ISupportInitialize)(this.nudN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvA)).EndInit();
            this.groupBoxMethod.ResumeLayout(false);
            this.groupBoxMethod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nudN;
        private System.Windows.Forms.Button btnCreateMatrix;
        private System.Windows.Forms.DataGridView dgvA;
        private System.Windows.Forms.TextBox txtEps;
        private System.Windows.Forms.Label lblN;
        private System.Windows.Forms.Label lblEps;
        private System.Windows.Forms.GroupBox groupBoxMethod;
        private System.Windows.Forms.RadioButton rbPower;
        private System.Windows.Forms.RadioButton rbJacobi;
        private System.Windows.Forms.Button btnSolve;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label lblResult;
    }
}
