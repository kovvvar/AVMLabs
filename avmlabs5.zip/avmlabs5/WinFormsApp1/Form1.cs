﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace EigenvaluesWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Создаем таблицу для матрицы A размера n×n.
        private void BtnCreateMatrix_Click(object sender, EventArgs e)
        {
            int n = (int)nudN.Value;
            dgvA.Columns.Clear();
            dgvA.Rows.Clear();

            for (int j = 0; j < n; j++)
            {
                var col = new DataGridViewTextBoxColumn();
                col.HeaderText = "A" + (j + 1);
                dgvA.Columns.Add(col);
            }

            dgvA.Rows.Add(n);
            for (int i = 0; i < n; i++)
            {
                dgvA.Rows[i].HeaderCell.Value = (i + 1).ToString();
            }
        }

        // Чтение матрицы A из DataGridView.
        private double[,] ReadMatrix()
        {
            int n = dgvA.ColumnCount;
            if (n == 0 || dgvA.RowCount != n)
                throw new Exception("Сначала создайте матрицу и заполните её.");

            double[,] A = new double[n, n];
            var ci = CultureInfo.CurrentCulture;
            var inv = CultureInfo.InvariantCulture;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    object val = dgvA.Rows[i].Cells[j].Value;
                    if (val == null)
                        throw new Exception($"Элемент A[{i + 1},{j + 1}] не заполнен.");

                    string s = val.ToString();

                    if (!double.TryParse(s, NumberStyles.Any, ci, out double x) &&
                        !double.TryParse(s, NumberStyles.Any, inv, out x))
                    {
                        throw new Exception($"Не удалось преобразовать A[{i + 1},{j + 1}] = '{s}' в число.");
                    }

                    A[i, j] = x;
                }
            }

            return A;
        }

        private double ReadEps()
        {
            var ci = CultureInfo.CurrentCulture;
            var inv = CultureInfo.InvariantCulture;
            string s = txtEps.Text.Trim();

            if (!double.TryParse(s, NumberStyles.Any, ci, out double eps) &&
                !double.TryParse(s, NumberStyles.Any, inv, out eps))
            {
                throw new Exception("Не удалось прочитать ε. Введите число.");
            }

            if (eps <= 0)
                throw new Exception("ε должно быть > 0.");

            return eps;
        }

        // Кнопка "Вычислить".
        private void BtnSolve_Click(object sender, EventArgs e)
        {
            try
            {
                txtResult.Clear();
                double[,] A = ReadMatrix();
                double eps = ReadEps();

                if (rbPower.Checked)
                {
                    int iterations;
                    double lambda = PowerIteration(A, eps, out iterations);

                    var sb = new StringBuilder();
                    sb.AppendLine("Метод прямой итерации (степенной метод):");
                    sb.AppendLine($"Максимальное по модулю собственное значение λ ≈ {lambda}");
                    sb.AppendLine($"Количество итераций: {iterations}");

                    txtResult.Text = sb.ToString();
                }
                else if (rbJacobi.Checked)
                {
                    int iterations;
                    double[] eigenvalues = JacobiEigenvalues(A, eps, out iterations);

                    var sb = new StringBuilder();
                    sb.AppendLine("Метод вращений Якоби (для симметричной матрицы):");
                    for (int i = 0; i < eigenvalues.Length; i++)
                    {
                        sb.AppendLine($"λ{i + 1} ≈ {eigenvalues[i]}");
                    }
                    sb.AppendLine($"Количество итераций: {iterations}");

                    txtResult.Text = sb.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // метод прямой итерации

        // Степенной метод: ищет максимальное по модулю собственное значение.
        // Возвращает λ, а в out - число итераций.
        private double PowerIteration(double[,] A, double eps, out int iterations)
        {
            int n = A.GetLength(0);
            double[] x = new double[n];

            for (int i = 0; i < n; i++)
                x[i] = 1.0;

            double lambdaOld = 0.0;
            double lambda = 0.0;
            iterations = 0;
            int maxIter = 10000;

            while (iterations < maxIter)
            {
                double[] y = MultiplyMatrixVector(A, x);

                double norm = VectorNorm(y);
                if (norm == 0)
                    throw new Exception("Норма вектора стала 0, степенной метод не применим.");

                for (int i = 0; i < n; i++)
                    x[i] = y[i] / norm;

                lambda = RayleighQuotient(A, x);

                iterations++;

                if (Math.Abs(lambda - lambdaOld) < eps)
                    break;

                lambdaOld = lambda;
            }

            if (iterations >= maxIter)
                throw new Exception("Степенной метод не сошёлся за максимально допустимое число итераций.");

            return lambda;
        }

        private double[] MultiplyMatrixVector(double[,] A, double[] x)
        {
            int n = A.GetLength(0);
            double[] y = new double[n];
            for (int i = 0; i < n; i++)
            {
                double sum = 0.0;
                for (int j = 0; j < n; j++)
                    sum += A[i, j] * x[j];
                y[i] = sum;
            }
            return y;
        }

        private double VectorNorm(double[] x)
        {
            double sum = 0.0;
            for (int i = 0; i < x.Length; i++)
                sum += x[i] * x[i];
            return Math.Sqrt(sum);
        }

        // Релеевская оценка: λ ≈ (x^T A x) / (x^T x)
        private double RayleighQuotient(double[,] A, double[] x)
        {
            int n = x.Length;
            double[] y = MultiplyMatrixVector(A, x);

            double num = 0.0;
            double den = 0.0;
            for (int i = 0; i < n; i++)
            {
                num += x[i] * y[i];
                den += x[i] * x[i];
            }

            if (Math.Abs(den) < 1e-20)
                return 0.0;

            return num / den;
        }

        // метод вращения Якоби
        // Метод Якоби: возвращает массив собственных значений симметричной матрицы A.
        private double[] JacobiEigenvalues(double[,] A, double eps, out int iterations)
        {
            int n = A.GetLength(0);
            if (A.GetLength(1) != n)
                throw new Exception("Матрица должна быть квадратной.");

            double[,] B = (double[,])A.Clone();

            iterations = 0;
            int maxIter = 10000;

            while (iterations < maxIter)
            {
                int p, q;
                double maxOff = MaxOffDiagonal(B, out p, out q);

                if (maxOff < eps)
                    break;

                double phi;
                if (Math.Abs(B[p, p] - B[q, q]) < 1e-20)
                {
                    phi = Math.PI / 4.0;
                }
                else
                {
                    phi = 0.5 * Math.Atan(2.0 * B[p, q] / (B[p, p] - B[q, q]));
                }

                double c = Math.Cos(phi);
                double s = Math.Sin(phi);

                ApplyJacobiRotation(B, p, q, c, s);

                iterations++;
            }

            if (iterations >= maxIter)
                throw new Exception("Метод Якоби не сошёлся за максимально допустимое число итераций.");

            double[] eigenvalues = new double[n];
            for (int i = 0; i < n; i++)
                eigenvalues[i] = B[i, i];

            return eigenvalues;
        }

        // Находит максимальный по модулю внедиагональный элемент матрицы.
        // Возвращает его модуль и индексы p, q.
        private double MaxOffDiagonal(double[,] A, out int p, out int q)
        {
            int n = A.GetLength(0);
            double max = 0.0;
            p = 0;
            q = 1;

            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    double val = Math.Abs(A[i, j]);
                    if (val > max)
                    {
                        max = val;
                        p = i;
                        q = j;
                    }
                }
            }

            return max;
        }

        // Применение вращения Якоби к матрице A (симметричная).
        // Вращаем плоскость (p, q) с параметрами c, s.
        private void ApplyJacobiRotation(double[,] A, int p, int q, double c, double s)
        {
            int n = A.GetLength(0);

            double app = A[p, p];
            double aqq = A[q, q];
            double apq = A[p, q];

            A[p, p] = c * c * app - 2.0 * s * c * apq + s * s * aqq;
            A[q, q] = s * s * app + 2.0 * s * c * apq + c * c * aqq;
            A[p, q] = 0.0;
            A[q, p] = 0.0;

            for (int k = 0; k < n; k++)
            {
                if (k == p || k == q) continue;

                double aik = A[k, p];
                double ajk = A[k, q];

                A[k, p] = c * aik - s * ajk;
                A[p, k] = A[k, p];

                A[k, q] = s * aik + c * ajk;
                A[q, k] = A[k, q];
            }
        }
    }
}
