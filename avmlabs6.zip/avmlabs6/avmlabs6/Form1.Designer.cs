﻿using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace CauchyNumericalMethods
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private TextBox txtH;
        private Label lblH;
        private Button btnSolve;
        private Chart chartSolution;
        private Label lblErrorEuler;
        private Label lblErrorRK2;
        private Label lblErrorEulerValue;
        private Label lblErrorRK2Value;

        // новое:
        private GroupBox grpCompare;
        private TextBox txtCompare;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtH = new System.Windows.Forms.TextBox();
            this.lblH = new System.Windows.Forms.Label();
            this.btnSolve = new System.Windows.Forms.Button();
            this.chartSolution = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lblErrorEuler = new System.Windows.Forms.Label();
            this.lblErrorRK2 = new System.Windows.Forms.Label();
            this.lblErrorEulerValue = new System.Windows.Forms.Label();
            this.lblErrorRK2Value = new System.Windows.Forms.Label();
            this.grpCompare = new System.Windows.Forms.GroupBox();
            this.txtCompare = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.chartSolution)).BeginInit();
            this.grpCompare.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtH
            // 
            this.txtH.Location = new System.Drawing.Point(80, 15);
            this.txtH.Name = "txtH";
            this.txtH.Size = new System.Drawing.Size(80, 20);
            this.txtH.TabIndex = 0;
            this.txtH.Text = "0,1";
            // 
            // lblH
            // 
            this.lblH.AutoSize = true;
            this.lblH.Location = new System.Drawing.Point(15, 18);
            this.lblH.Name = "lblH";
            this.lblH.Size = new System.Drawing.Size(40, 13);
            this.lblH.TabIndex = 1;
            this.lblH.Text = "Шаг h:";
            // 
            // btnSolve
            // 
            this.btnSolve.Location = new System.Drawing.Point(18, 50);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(142, 30);
            this.btnSolve.TabIndex = 2;
            this.btnSolve.Text = "Решить и построить";
            this.btnSolve.UseVisualStyleBackColor = true;
            this.btnSolve.Click += new System.EventHandler(this.BtnSolve_Click);
            // 
            // chartSolution
            // 
            ChartArea chartArea1 = new ChartArea();
            Legend legend1 = new Legend();
            chartArea1.Name = "ChartArea1";
            this.chartSolution.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartSolution.Legends.Add(legend1);
            this.chartSolution.Location = new System.Drawing.Point(180, 10);
            this.chartSolution.Name = "chartSolution";
            this.chartSolution.Size = new System.Drawing.Size(600, 400);
            this.chartSolution.TabIndex = 3;
            this.chartSolution.Text = "chartSolution";
            // 
            // lblErrorEuler
            // 
            this.lblErrorEuler.AutoSize = true;
            this.lblErrorEuler.Location = new System.Drawing.Point(15, 100);
            this.lblErrorEuler.Name = "lblErrorEuler";
            this.lblErrorEuler.Size = new System.Drawing.Size(104, 13);
            this.lblErrorEuler.TabIndex = 4;
            this.lblErrorEuler.Text = "Ошибка Эйлера max:";
            // 
            // lblErrorRK2
            // 
            this.lblErrorRK2.AutoSize = true;
            this.lblErrorRK2.Location = new System.Drawing.Point(15, 120);
            this.lblErrorRK2.Name = "lblErrorRK2";
            this.lblErrorRK2.Size = new System.Drawing.Size(110, 13);
            this.lblErrorRK2.TabIndex = 5;
            this.lblErrorRK2.Text = "Ошибка РК2 max   :";
            // 
            // lblErrorEulerValue
            // 
            this.lblErrorEulerValue.AutoSize = true;
            this.lblErrorEulerValue.Location = new System.Drawing.Point(140, 100);
            this.lblErrorEulerValue.Name = "lblErrorEulerValue";
            this.lblErrorEulerValue.Size = new System.Drawing.Size(13, 13);
            this.lblErrorEulerValue.TabIndex = 6;
            this.lblErrorEulerValue.Text = "0";
            // 
            // lblErrorRK2Value
            // 
            this.lblErrorRK2Value.AutoSize = true;
            this.lblErrorRK2Value.Location = new System.Drawing.Point(140, 120);
            this.lblErrorRK2Value.Name = "lblErrorRK2Value";
            this.lblErrorRK2Value.Size = new System.Drawing.Size(13, 13);
            this.lblErrorRK2Value.TabIndex = 7;
            this.lblErrorRK2Value.Text = "0";
            // 
            // grpCompare
            // 
            this.grpCompare.Controls.Add(this.txtCompare);
            this.grpCompare.Location = new System.Drawing.Point(18, 150);
            this.grpCompare.Name = "grpCompare";
            this.grpCompare.Size = new System.Drawing.Size(160, 260);
            this.grpCompare.TabIndex = 8;
            this.grpCompare.TabStop = false;
            this.grpCompare.Text = "Сравнение методов";
            // 
            // txtCompare
            // 
            this.txtCompare.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCompare.Location = new System.Drawing.Point(3, 16);
            this.txtCompare.Multiline = true;
            this.txtCompare.Name = "txtCompare";
            this.txtCompare.ReadOnly = true;
            this.txtCompare.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCompare.Size = new System.Drawing.Size(154, 241);
            this.txtCompare.TabIndex = 0;
            this.txtCompare.Font = new System.Drawing.Font("Consolas", 8.25F);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 430);
            this.Controls.Add(this.grpCompare);
            this.Controls.Add(this.lblErrorRK2Value);
            this.Controls.Add(this.lblErrorEulerValue);
            this.Controls.Add(this.lblErrorRK2);
            this.Controls.Add(this.lblErrorEuler);
            this.Controls.Add(this.chartSolution);
            this.Controls.Add(this.btnSolve);
            this.Controls.Add(this.lblH);
            this.Controls.Add(this.txtH);
            this.Name = "Form1";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Численное решение задачи Коши (Эйлер, РК2)";
            ((System.ComponentModel.ISupportInitialize)(this.chartSolution)).EndInit();
            this.grpCompare.ResumeLayout(false);
            this.grpCompare.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
