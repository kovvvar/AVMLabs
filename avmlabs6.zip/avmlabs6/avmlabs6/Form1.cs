﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace CauchyNumericalMethods
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Решаем задачу Коши y' = y, y(0) = 1 на [0,1]
        private void BtnSolve_Click(object sender, EventArgs e)
        {
            try
            {
                double h = ReadStep();
                if (h <= 0 || h > 1.0)
                    throw new Exception("Шаг h должен быть в (0, 1].");

                int n = (int)Math.Round(1.0 / h);
                double[] xs = new double[n + 1];

                for (int k = 0; k <= n; k++)
                    xs[k] = k * h;

                // Точное решение
                double[] yExact = new double[n + 1];
                for (int k = 0; k <= n; k++)
                    yExact[k] = Math.Exp(xs[k]);

                // Численное решение Эйлера
                double[] yEuler = SolveEuler(xs, h);

                // Численное решение Рунге–Кутта 2-го порядка
                double[] yRK2 = SolveRK2(xs, h);

                // Обновляем график
                DrawChart(xs, yExact, yEuler, yRK2);

                // Ошибки
                double errEuler = MaxError(yExact, yEuler);
                double errRK2 = MaxError(yExact, yRK2);

                lblErrorEulerValue.Text = errEuler.ToString("0.0000E+0", CultureInfo.InvariantCulture);
                lblErrorRK2Value.Text = errRK2.ToString("0.0000E+0", CultureInfo.InvariantCulture);

                // Формируем красивое окно сравнения
                var sb = new StringBuilder();
                sb.AppendLine("СРАВНЕНИЕ МЕТОДОВ");
                sb.AppendLine();
                sb.AppendLine($"Шаг h = {h:0.000}");
                sb.AppendLine($"Точек: {xs.Length}");
                sb.AppendLine();
                sb.AppendLine($"Эйлер: {errEuler:0.0000E+0}");
                sb.AppendLine($"РК2  : {errRK2:0.0000E+0}");

                if (errRK2 > 0)
                {
                    double ratio = errEuler / errRK2;
                    sb.AppendLine();
                    sb.AppendLine($"РК2 точнее в {ratio:0.00} раз");
                }

                txtCompare.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private double ReadStep()
        {
            string s = txtH.Text.Trim();
            var ci = CultureInfo.CurrentCulture;
            var inv = CultureInfo.InvariantCulture;

            if (!double.TryParse(s, NumberStyles.Any, ci, out double h) &&
                !double.TryParse(s, NumberStyles.Any, inv, out h))
            {
                throw new Exception("Не удалось прочитать шаг h. Введите число.");
            }

            return h;
        }

        // Метод Эйлера для y' = y, y(0) = 1
        private double[] SolveEuler(double[] xs, double h)
        {
            int n = xs.Length - 1;
            double[] y = new double[n + 1];
            y[0] = 1.0; // начальное условие

            for (int k = 0; k < n; k++)
            {
                double f = y[k];       // f(x, y) = y
                y[k + 1] = y[k] + h * f;
            }

            return y;
        }

        // Метод Рунге–Кутта 2-го порядка (модифицированный Эйлер) для y' = y
        private double[] SolveRK2(double[] xs, double h)
        {
            int n = xs.Length - 1;
            double[] y = new double[n + 1];
            y[0] = 1.0; // начальное условие

            for (int k = 0; k < n; k++)
            {
                double xk = xs[k];
                double yk = y[k];

                double k1 = yk;                    // f(xk, yk)
                double k2 = yk + h * k1;           // f(xk + h, yk + h*k1) = yk + h*k1

                y[k + 1] = yk + h * 0.5 * (k1 + k2);
            }

            return y;
        }

        private void DrawChart(double[] xs, double[] yExact, double[] yEuler, double[] yRK2)
        {
            chartSolution.Series.Clear();

            var sExact = new Series("Точное решение");
            sExact.ChartType = SeriesChartType.Line;
            sExact.BorderWidth = 2;

            var sEuler = new Series("Метод Эйлера");
            sEuler.ChartType = SeriesChartType.Line;
            sEuler.BorderWidth = 2;

            var sRK2 = new Series("Метод Рунге–Кутта 2-го порядка");
            sRK2.ChartType = SeriesChartType.Line;
            sRK2.BorderWidth = 2;

            for (int i = 0; i < xs.Length; i++)
            {
                sExact.Points.AddXY(xs[i], yExact[i]);
                sEuler.Points.AddXY(xs[i], yEuler[i]);
                sRK2.Points.AddXY(xs[i], yRK2[i]);
            }

            chartSolution.Series.Add(sExact);
            chartSolution.Series.Add(sEuler);
            chartSolution.Series.Add(sRK2);

            chartSolution.ChartAreas[0].RecalculateAxesScale();
        }

        private double MaxError(double[] yExact, double[] yNum)
        {
            double max = 0.0;
            for (int i = 0; i < yExact.Length; i++)
            {
                double diff = Math.Abs(yExact[i] - yNum[i]);
                if (diff > max)
                    max = diff;
            }
            return max;
        }
    }
}
