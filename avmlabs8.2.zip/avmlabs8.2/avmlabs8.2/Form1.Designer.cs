﻿namespace NewtonSystem2Eq
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblF1;
        private System.Windows.Forms.TextBox txtF1;
        private System.Windows.Forms.Label lblF2;
        private System.Windows.Forms.TextBox txtF2;

        private System.Windows.Forms.Label lblX0;
        private System.Windows.Forms.TextBox txtX0;
        private System.Windows.Forms.Label lblY0;
        private System.Windows.Forms.TextBox txtY0;

        private System.Windows.Forms.Label lblEps;
        private System.Windows.Forms.TextBox txtEps;

        private System.Windows.Forms.Button btnSolve;
        private System.Windows.Forms.TextBox txtResult;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblF1 = new System.Windows.Forms.Label();
            this.txtF1 = new System.Windows.Forms.TextBox();
            this.lblF2 = new System.Windows.Forms.Label();
            this.txtF2 = new System.Windows.Forms.TextBox();
            this.lblX0 = new System.Windows.Forms.Label();
            this.txtX0 = new System.Windows.Forms.TextBox();
            this.lblY0 = new System.Windows.Forms.Label();
            this.txtY0 = new System.Windows.Forms.TextBox();
            this.lblEps = new System.Windows.Forms.Label();
            this.txtEps = new System.Windows.Forms.TextBox();
            this.btnSolve = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblF1
            // 
            this.lblF1.AutoSize = true;
            this.lblF1.Location = new System.Drawing.Point(12, 12);
            this.lblF1.Name = "lblF1";
            this.lblF1.Size = new System.Drawing.Size(48, 13);
            this.lblF1.TabIndex = 0;
            this.lblF1.Text = "F1(x,y)=";
            // 
            // txtF1
            // 
            this.txtF1.Location = new System.Drawing.Point(15, 30);
            this.txtF1.Name = "txtF1";
            this.txtF1.Size = new System.Drawing.Size(560, 20);
            this.txtF1.TabIndex = 1;
            this.txtF1.Text = "x^2 + y^2 - 1";
            // 
            // lblF2
            // 
            this.lblF2.AutoSize = true;
            this.lblF2.Location = new System.Drawing.Point(12, 58);
            this.lblF2.Name = "lblF2";
            this.lblF2.Size = new System.Drawing.Size(48, 13);
            this.lblF2.TabIndex = 2;
            this.lblF2.Text = "F2(x,y)=";
            // 
            // txtF2
            // 
            this.txtF2.Location = new System.Drawing.Point(15, 76);
            this.txtF2.Name = "txtF2";
            this.txtF2.Size = new System.Drawing.Size(560, 20);
            this.txtF2.TabIndex = 3;
            this.txtF2.Text = "x - y";
            // 
            // lblX0
            // 
            this.lblX0.AutoSize = true;
            this.lblX0.Location = new System.Drawing.Point(12, 110);
            this.lblX0.Name = "lblX0";
            this.lblX0.Size = new System.Drawing.Size(20, 13);
            this.lblX0.TabIndex = 4;
            this.lblX0.Text = "x0:";
            // 
            // txtX0
            // 
            this.txtX0.Location = new System.Drawing.Point(38, 107);
            this.txtX0.Name = "txtX0";
            this.txtX0.Size = new System.Drawing.Size(90, 20);
            this.txtX0.TabIndex = 5;
            this.txtX0.Text = "0.7";
            // 
            // lblY0
            // 
            this.lblY0.AutoSize = true;
            this.lblY0.Location = new System.Drawing.Point(145, 110);
            this.lblY0.Name = "lblY0";
            this.lblY0.Size = new System.Drawing.Size(20, 13);
            this.lblY0.TabIndex = 6;
            this.lblY0.Text = "y0:";
            // 
            // txtY0
            // 
            this.txtY0.Location = new System.Drawing.Point(171, 107);
            this.txtY0.Name = "txtY0";
            this.txtY0.Size = new System.Drawing.Size(90, 20);
            this.txtY0.TabIndex = 7;
            this.txtY0.Text = "0.7";
            // 
            // lblEps
            // 
            this.lblEps.AutoSize = true;
            this.lblEps.Location = new System.Drawing.Point(285, 110);
            this.lblEps.Name = "lblEps";
            this.lblEps.Size = new System.Drawing.Size(24, 13);
            this.lblEps.TabIndex = 8;
            this.lblEps.Text = "ε =";
            // 
            // txtEps
            // 
            this.txtEps.Location = new System.Drawing.Point(315, 107);
            this.txtEps.Name = "txtEps";
            this.txtEps.Size = new System.Drawing.Size(90, 20);
            this.txtEps.TabIndex = 9;
            this.txtEps.Text = "1e-6";
            // 
            // btnSolve
            // 
            this.btnSolve.Location = new System.Drawing.Point(15, 140);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(200, 30);
            this.btnSolve.TabIndex = 10;
            this.btnSolve.Text = "Решить (Ньютон)";
            this.btnSolve.UseVisualStyleBackColor = true;
            this.btnSolve.Click += new System.EventHandler(this.BtnSolve_Click);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(15, 185);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResult.Size = new System.Drawing.Size(560, 260);
            this.txtResult.TabIndex = 11;
            this.txtResult.Font = new System.Drawing.Font("Consolas", 9F);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(592, 460);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnSolve);
            this.Controls.Add(this.txtEps);
            this.Controls.Add(this.lblEps);
            this.Controls.Add(this.txtY0);
            this.Controls.Add(this.lblY0);
            this.Controls.Add(this.txtX0);
            this.Controls.Add(this.lblX0);
            this.Controls.Add(this.txtF2);
            this.Controls.Add(this.lblF2);
            this.Controls.Add(this.txtF1);
            this.Controls.Add(this.lblF1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Метод Ньютона для системы 2 уравнений";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
