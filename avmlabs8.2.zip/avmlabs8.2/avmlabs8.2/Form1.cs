﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace NewtonSystem2Eq
{
    public partial class Form1 : Form
    {
        private const int MaxIter = 100;
        private const double DiffH = 1e-6; // шаг для численных производных

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSolve_Click(object sender, EventArgs e)
        {
            try
            {
                string f1Str = txtF1.Text.Trim();
                string f2Str = txtF2.Text.Trim();

                double x = ReadDouble(txtX0.Text, "x0");
                double y = ReadDouble(txtY0.Text, "y0");
                double eps = ReadDouble(txtEps.Text, "ε");
                if (eps <= 0) throw new Exception("ε должно быть > 0.");

                Func<double, double, double> F1 = (xx, yy) => ExpressionEvaluator2D.Evaluate(f1Str, xx, yy);
                Func<double, double, double> F2 = (xx, yy) => ExpressionEvaluator2D.Evaluate(f2Str, xx, yy);

                var res = NewtonSystem(F1, F2, x, y, eps);

                txtResult.Text = FormatResult(f1Str, f2Str, res, F1, F2);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private double ReadDouble(string s, string name)
        {
            s = s.Trim().Replace(',', '.');
            if (!double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out double v))
                throw new Exception($"Не удалось прочитать {name}.");
            return v;
        }

        private (double x, double y, int iterations, bool converged, string note) NewtonSystem(
            Func<double, double, double> f1,
            Func<double, double, double> f2,
            double x0,
            double y0,
            double eps)
        {
            double x = x0;
            double y = y0;

            for (int iter = 1; iter <= MaxIter; iter++)
            {
                double F1 = f1(x, y);
                double F2 = f2(x, y);

                // критерий по функциям
                if (Math.Max(Math.Abs(F1), Math.Abs(F2)) < eps)
                    return (x, y, iter - 1, true, null);

                // Якобиан J = [dF1/dx dF1/dy; dF2/dx dF2/dy]
                double a = d_dx(f1, x, y);
                double b = d_dy(f1, x, y);
                double c = d_dx(f2, x, y);
                double d = d_dy(f2, x, y);

                // Решаем систему:
                // [a b][dx] = -[F1]
                // [c d][dy]   [F2]
                double det = a * d - b * c;
                if (Math.Abs(det) < 1e-14)
                    return (x, y, iter, false, "Якобиан вырожден (det близок к 0). Попробуйте другие начальные приближения.");

                double dx = (-F1 * d - b * (-F2)) / det; // ( -F1*d - b*(-F2) )/det
                double dy = (a * (-F2) - (-F1) * c) / det;

                double xNext = x + dx;
                double yNext = y + dy;

                // критерий по шагу
                if (Math.Max(Math.Abs(dx), Math.Abs(dy)) < eps)
                    return (xNext, yNext, iter, true, null);

                x = xNext;
                y = yNext;
            }

            return (x, y, MaxIter, false, "Превышено максимальное число итераций.");
        }

        // Численные производные (центральная разность)
        private double d_dx(Func<double, double, double> f, double x, double y)
            => (f(x + DiffH, y) - f(x - DiffH, y)) / (2.0 * DiffH);

        private double d_dy(Func<double, double, double> f, double x, double y)
            => (f(x, y + DiffH) - f(x, y - DiffH)) / (2.0 * DiffH);

        private string FormatResult(
            string f1Str,
            string f2Str,
            (double x, double y, int iterations, bool converged, string note) res,
            Func<double, double, double> f1,
            Func<double, double, double> f2)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Метод Ньютона для системы 2 уравнений");
            sb.AppendLine(new string('-', 60));
            sb.AppendLine($"F1(x,y): {f1Str}");
            sb.AppendLine($"F2(x,y): {f2Str}");
            sb.AppendLine();

            sb.AppendLine($"Статус: {(res.converged ? "сошёлся" : "не сошёлся")}");
            if (!string.IsNullOrWhiteSpace(res.note))
                sb.AppendLine($"Примечание: {res.note}");
            sb.AppendLine($"Итераций: {res.iterations}");
            sb.AppendLine();

            sb.AppendLine($"x ≈ {res.x.ToString("0.###############", CultureInfo.InvariantCulture)}");
            sb.AppendLine($"y ≈ {res.y.ToString("0.###############", CultureInfo.InvariantCulture)}");
            sb.AppendLine();

            sb.AppendLine($"|F1(x,y)| = {Math.Abs(f1(res.x, res.y)).ToString("0.000000E+0", CultureInfo.InvariantCulture)}");
            sb.AppendLine($"|F2(x,y)| = {Math.Abs(f2(res.x, res.y)).ToString("0.000000E+0", CultureInfo.InvariantCulture)}");

            return sb.ToString();
        }
    }
}
